import json
import boto3

def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('WeatherLocations')

    # Assuming 'event' is a dictionary containing latitude, longitude, locationName, and timeRange
    response = table.put_item(
       Item={
            'locationName': event['locationName'],
            'latitude': event['latitude'],
            'longitude': event['longitude'],
            'timeRange': event['timeRange']
        }
    )

    return {
        'statusCode': 200,
        'body': json.dumps('Location saved successfully')
    }
