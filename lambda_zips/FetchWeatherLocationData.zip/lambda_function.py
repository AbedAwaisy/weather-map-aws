import json
import boto3

def lambda_handler(event, context):
    # Parse the location name from the event
    location_name = event.get('locationName')
    
    # Create a DynamoDB client
    dynamodb = boto3.resource('dynamodb')
    
    # Specify your DynamoDB table
    table = dynamodb.Table('WeatherLocations')
    
    # Query the table for the location
    response = table.get_item(
        Key={
            'locationName': location_name
        }
    )
    
    # Extract the item from the response
    item = response.get('Item', {})

    return {
        'statusCode': 200,
        'body': json.dumps(item)
    }
